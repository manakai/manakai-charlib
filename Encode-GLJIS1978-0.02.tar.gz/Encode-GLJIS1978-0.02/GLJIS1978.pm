package Encode::GLJIS1978;
our $VERSION = "0.02";
 
use Encode;
use XSLoader;
XSLoader::load(__PACKAGE__,$VERSION);

1;
__END__

=head1 NAME

Encode::GLJIS1978 - Encode module for the charset C<gl-jis-1978>

=head1 SYNOPSIS

  use Encode;
  use Encode::GLJIS1978;
  my $bytes = encode 'gl-jis-1978', $chars;
  my $chars = decode 'gl-jis-1978', $bytes;

=head1 SEE ALSO

manakai-charlib <http://suika.fam.cx/www/manakai-charlib/readme>.

=head1 AUTHOR

Wakaba <w@suika.fam.cx>.

=head1 LICENSE

Copyright 2006-2010 Wakaba <w@suika.fam.cx>.

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.
