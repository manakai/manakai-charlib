package Encode::ShiftJIS1997;
our $VERSION = "0.02";
 
use Encode;
use XSLoader;
XSLoader::load(__PACKAGE__,$VERSION);

1;
__END__

=head1 NAME

Encode::ShiftJIS1997 - Encode module for the charset C<shift-jis-1997>

=head1 SYNOPSIS

  use Encode;
  use Encode::ShiftJIS1997;
  my $bytes = encode 'shift-jis-1997', $chars;
  my $chars = decode 'shift-jis-1997', $bytes;

=head1 SEE ALSO

manakai-charlib <http://suika.fam.cx/www/manakai-charlib/readme>.

=head1 AUTHOR

Wakaba <w@suika.fam.cx>.

=head1 LICENSE

Copyright 2006-2010 Wakaba <w@suika.fam.cx>.

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.
