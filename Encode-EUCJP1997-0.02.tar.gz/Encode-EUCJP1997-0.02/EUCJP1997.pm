package Encode::EUCJP1997;
our $VERSION = "0.02";
 
use Encode;
use XSLoader;
XSLoader::load(__PACKAGE__,$VERSION);

1;
__END__

=head1 NAME
 
Encode::EUCJP1997 - New Encoding
 
=head1 SYNOPSIS

You got to fill this in!

=head1 SEE ALSO

L<Encode>

=cut
