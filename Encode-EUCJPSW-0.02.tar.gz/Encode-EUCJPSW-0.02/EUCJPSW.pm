package Encode::EUCJPSW;
our $VERSION = "0.02";
 
use Encode;
use XSLoader;
XSLoader::load(__PACKAGE__,$VERSION);

1;
__END__

=head1 NAME

Encode::EUCJPSW - Encode module for the charset C<euc-jp-sw>

=head1 SYNOPSIS

  use Encode;
  use Encode::EUCJPSW;
  my $bytes = encode 'euc-jp-sw', $chars;
  my $chars = decode 'euc-jp-sw', $bytes;

=head1 SEE ALSO

manakai-charlib <http://suika.fam.cx/www/manakai-charlib/readme>.

=head1 AUTHOR

Wakaba <w@suika.fam.cx>.

=head1 LICENSE

Copyright 2006-2010 Wakaba <w@suika.fam.cx>.

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.
